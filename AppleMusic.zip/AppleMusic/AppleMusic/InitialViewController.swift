//
//  InitialViewController.swift
//  AppleMusic
//
//  Created by Илья on 19.12.2023.
//

import UIKit
import CoreData

class InitialViewController: UIViewController {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.text = "Введите свое имя"
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    lazy var nameTextField: UITextField = {
        let textField = UITextField()
        textField.placeholder = "Имя"
        textField.borderStyle = .roundedRect
        textField.translatesAutoresizingMaskIntoConstraints = false
        return textField
    }()
    
    lazy var goButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Go", for: .normal)
        button.addTarget(self, action: #selector(goButtonTapped), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        
        view.addSubview(nameLabel)
        view.addSubview(nameTextField)
        view.addSubview(goButton)
        
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
            nameLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            nameLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            nameTextField.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 20),
            nameTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            nameTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            
            goButton.topAnchor.constraint(equalTo: nameTextField.bottomAnchor, constant: 20),
            goButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
        
        if let savedName = loadUserName() {
            nameTextField.text = savedName
        }
    }
    
    @objc func goButtonTapped() {
        saveUserName(name: nameTextField.text)
        let nextViewController = MainTabBarController()
        navigationController?.pushViewController(nextViewController, animated: true)
        navigationController?.viewControllers.removeAll { $0 is InitialViewController }
    }
    
    func saveUserName(name: String?) {
        deleteUserData()
        let newUser = User(context: context)
        newUser.name = name
        
        do {
            try context.save()
        } catch {
            print("Error saving user data: \(error)")
        }
    }
    
    func loadUserName() -> String? {
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        
        do {
            let users = try context.fetch(fetchRequest)
            return users.first?.name
        } catch {
            print("Error fetching user data: \(error)")
            return nil
        }
    }
    
    func deleteUserData() {
        let fetchRequest: NSFetchRequest<User> = User.fetchRequest()
        
        do {
            let users = try context.fetch(fetchRequest)
            for user in users {
                context.delete(user)
            }
            
            try context.save()
        } catch {
            print("Error deleting user data: \(error)")
        }
    }
}

