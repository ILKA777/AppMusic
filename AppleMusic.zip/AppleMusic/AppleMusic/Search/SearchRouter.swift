//
//  SearchRouter.swift
//  AppleMusic
//
//  Created by Илья on 16.12.2023.
//  Copyright (c) 2023 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol SearchRoutingLogic {

}

class SearchRouter: NSObject, SearchRoutingLogic {

  weak var viewController: SearchViewController?
  
  // MARK: Routing
  
}
