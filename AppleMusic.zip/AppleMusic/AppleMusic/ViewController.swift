//
//  ViewController.swift
//  AppleMusic
//
//  Created by Илья on 14.12.2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
    }
}

